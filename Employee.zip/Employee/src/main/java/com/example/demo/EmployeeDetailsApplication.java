package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.util.ArrayList;
import java.util.List;

@SpringBootApplication
public class EmployeeDetailsApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeDetailsApplication.class, args);
	List<Employee> employees = new ArrayList<>();

        for (int i = 0; i < 10; i++) {
		employees.add(new HourlyEmployee());
		employees.add(new SalariedEmployee());
		employees.add(new Managers());
	}

	// Examples:
	Employee firstHourlyEmployee = employees.get(0);
        firstHourlyEmployee.work(180);
        System.out.println("Vacation days accumulated: " + firstHourlyEmployee.getVacationDays());

		firstHourlyEmployee.takeVacation(4);
        System.out.println("Vacation days remaining: " + firstHourlyEmployee.getVacationDays());
}
}
