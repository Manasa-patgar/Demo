package com.example.demo;


public class SalariedEmployee extends Employee {

    private static final float VACATION_DAYS_PER_YEAR = 15;

    public SalariedEmployee() {
        setVacationDays(VACATION_DAYS_PER_YEAR);
    }

}
