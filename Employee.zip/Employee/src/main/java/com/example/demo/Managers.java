package com.example.demo;

public class Managers extends SalariedEmployee{

    private static final float VACATION_DAYS_PER_YEAR = 30;

    public Managers() {
        setVacationDays(VACATION_DAYS_PER_YEAR);
    }
}
