package com.example.demo;

public class HourlyEmployee extends Employee{

    private static final float VACATION_DAYS_PER_YEAR = 10;

    public HourlyEmployee() {
        setVacationDays(VACATION_DAYS_PER_YEAR);
    }

}
