package com.example.demo;

import java.util.UUID;


public abstract class  Employee {

   private static final int MAX_WORK_DAYS = 260;
    private float vacationDays;

    public Employee() {
        this.vacationDays = 0;
    }

    public float getVacationDays() {
        return vacationDays;
    }

    protected void setVacationDays(float vacationDays) {
        this.vacationDays = vacationDays;
    }

    public void work(int noOfDaysWorked) {
        if (noOfDaysWorked < 0 || noOfDaysWorked > MAX_WORK_DAYS) {
            throw new IllegalArgumentException("Invalid number of days worked.");
        }

        if (noOfDaysWorked <= (MAX_WORK_DAYS - vacationDays)) {
            vacationDays += noOfDaysWorked;
        } else {
            vacationDays = MAX_WORK_DAYS;
        }
    }
    public void takeVacation(float noOfVacationDaysUsed) {
        if(noOfVacationDaysUsed > 0 || noOfVacationDaysUsed <  vacationDays) {
            vacationDays -= noOfVacationDaysUsed;
        }
        else
        {
            throw new IllegalArgumentException("You cannot apply for vacation as you don't have enough number of vacation days");
        }
    }
}
